<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-02
 * Time: 15:19
 */

namespace app\src\rfpay\utils;


class CryptException extends \Exception
{
    
}