<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-28
 * Time: 9:13
 */

namespace app\src\rfpay\po;


class RfNoCardOrderSmsResp extends RfBaseResp
{
    

}