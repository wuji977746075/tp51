<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-28
 * Time: 9:23
 */

namespace app\src\rfpay\po;


class RfNoCardOrderPayResp extends RfBaseResp
{
    
}