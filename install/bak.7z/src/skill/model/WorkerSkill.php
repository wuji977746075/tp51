<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-15
 * Time: 17:10
 */

namespace app\src\skill\model;


use think\Model;

class WorkerSkill extends Model
{
    protected $table = "itboye_worker_skill";
}