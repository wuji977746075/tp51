<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-19
 * Time: 14:39
 */

namespace app\src\sku\model;

use think\Model;

class Sku extends Model
{
    
}