<?php
/**
 * Copyright (c) 2016.  hangzhou BOYE .Co.Ltd. All rights reserved
 */

/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-12-17
 * Time: 16:26
 */

namespace app\src\store\model;


use think\Model;

class StorePromotion extends Model
{

}