<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-26
 * Time: 19:46
 */

namespace app\src\i18n\model;


use think\Model;

class MultiLanguage extends Model
{
    
}