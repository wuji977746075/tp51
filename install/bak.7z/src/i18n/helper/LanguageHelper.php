<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-26
 * Time: 20:06
 */

namespace app\src\i18n\helper;


class LanguageHelper
{

    /**
     * 获取类目名称 - 语言配置信息
     * @author hebidu <email:346551990@qq.com>
     */
    public static function getCategoryName(){
        
        return [
            'tb_name'=>'itboye_category',
            'field_name'=>'name'
        ];
    }

}