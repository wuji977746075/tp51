<?php

/**
 * Created by PhpStorm.
 * User: Zhoujinda
 * Date: 2017/1/4
 * Time: 17:51
 */
namespace app\src\repairerApply\model;

class RepairerApply extends \think\Model{

}