<?php

namespace app\src\system\model;

use think\Model;

class Sign extends Model{
  protected $table = "itboye_signin";
}