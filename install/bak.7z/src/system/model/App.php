<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-09
 * Time: 22:18
 */

namespace app\src\system\model;


use think\Model;

class App extends Model
{
    
}