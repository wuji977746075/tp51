<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-10
 * Time: 16:35
 */

namespace app\src\system\model;


use think\Model;

class Log extends Model
{
    protected $table = "common_log";
}