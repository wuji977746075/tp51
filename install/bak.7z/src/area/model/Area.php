<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-10-15
 * Time: 17:10
 */

namespace app\src\area\model;


use think\Model;

class Area extends Model
{
    protected $table = "common_area";
}