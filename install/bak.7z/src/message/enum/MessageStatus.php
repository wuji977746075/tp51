<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-11-03
 * Time: 15:23
 */

namespace app\src\message\enum;


class MessageStatus
{
    const NOT_READ = 0;

    const READ = 1;

    const DELETE = 2;
}