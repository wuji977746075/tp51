<?php
/**
 * Created by PhpStorm.
 * User: 1
 * Date: 2016-11-03
 * Time: 15:06
 */

namespace app\src\message\model;


use think\Model;

class MessageBox extends Model
{

}