<?php

/**
 * 消息内容节点序列
 * @author auto create
 */
class MessageItem
{
	
	/** 
	 * 节点类型
	 **/
	public $type;
	
	/** 
	 * 节点值
	 **/
	public $value;	
}
?>