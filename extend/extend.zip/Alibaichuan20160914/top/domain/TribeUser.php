<?php

/**
 * OPENIM群成员信息
 * @author auto create
 */
class TribeUser
{
	
	/** 
	 * 账户appkey
	 **/
	public $app_key;
	
	/** 
	 * 群成员角色
	 **/
	public $role;
	
	/** 
	 * 是否为淘宝账号
	 **/
	public $taobao_account;
	
	/** 
	 * 用户id
	 **/
	public $uid;	
}
?>