<?php

/**
 * 村淘特有商品级数据结构
 * @author auto create
 */
class CuntaoItemSpecific
{
	
	/** 
	 * 村淘商品级佣金率
	 **/
	public $kick_back_rate;	
}
?>